'''Program to create a bug tracker'''
#Import modules to be used in the program
import tkinter as tk
from tkinter import Button, Toplevel, Frame, Entry
from tkinter import Label, messagebox, StringVar, OptionMenu
import json

root = tk.Tk()
root.title("Bug Tracker")
root_frame = Frame(root)
root_frame.pack()

with open("bugs.json",'r',encoding='ascii') as bugs:
    bugsdict = json.load(bugs)

def add_bug():
    '''Add a bug to the bug tracker'''
    def add_to_json():
        '''Add the bug to the json file'''
        #Create dictionary to hold all bug info
        bug = {field:entries[field].get() for field in fields}
        bug["severity"] = severity_var.get()
        bugsdict["found"].append(bug)
        with open("bugs.json",'w',encoding='ascii') as bugs2:
            json.dump(bugsdict,bugs2)
        messagebox.showinfo("Added bug","Added bug to file!")
        add_bug_w.destroy()
        create_window()
    fields = ["Bug ID","Date","Scope","Location","First Responder","Manager","Server ID"]
    #Hold all the entry fields
    entries = {}
    add_bug_w = Toplevel(root)
    add_bug_wf = Frame(add_bug_w)
    add_bug_wf.pack()
    for i, field in enumerate(fields):
        label = Label(add_bug_wf,text=field + ":")
        label.grid(row=i,column=0)
        entry = Entry(add_bug_wf)
        entry.grid(row=i,column=1)
        entries[field] = entry
    #Severity
    severity_options = ["low","meduim","high"]
    severity_var = StringVar(add_bug_wf)
    severity_var.set(severity_options[0])
    severity_label = Label(add_bug_wf,text="Severity")
    severity_label.grid(row=7,column=0)
    severity_entry = OptionMenu(add_bug_wf,severity_var,*severity_options)
    severity_entry.grid(row=7,column=1)
    #Submit button for all the information
    submit_button = Button(add_bug_wf,text="Submit",
                    command=add_to_json)
    submit_button.grid(row=8, column=0, columnspan=2)

def show_info(place,bug):
    '''Show information about the bug'''
    def move_bug():
        '''Move the bug to the next stage'''
        moving_bug = bugsdict[place].pop(bug)
        if place == "found":
            bugsdict["in progress"].append(moving_bug)
        elif place == "in progress":
            bugsdict["testing"].append(moving_bug)
        elif place == "testing":
            bugsdict["completed"].append(moving_bug)
        with open("bugs.json","w",encoding="ascii") as bugs2:
            json.dump(bugsdict,bugs2)
        bug_info_w.destroy()
        create_window()
    def edit_bug():
        '''Edit the bug information'''
        def edit_json():
            '''Edit the json'''
            #Edit the entry of bugsdict
            for field in fields:
                bugsdict[place][bug][field] = entries[field].get()
            bugsdict[place][bug]["severity"] = severity_var.get()
            #Place new entry in json file
            with open("bugs.json",'w',encoding='ascii') as bugs2:
                json.dump(bugsdict,bugs2)
            edit_bug_w.destroy()
            bug_info_w.destroy()
            create_window()
        fields = ["Bug ID","Date","Scope","Location","First Responder","Manager","Server ID"]
        entries = {}
        edit_bug_w = Toplevel(root)
        edit_bug_wf = Frame(edit_bug_w)
        edit_bug_wf.pack()
        for i, field in enumerate(fields):
            label = Label(edit_bug_wf,text=field + ":")
            label.grid(row=i,column=0)
            entry = Entry(edit_bug_wf)
            entry.insert(0,bugsdict[place][bug][field])
            entry.grid(row=i,column=1)
            entries[field] = entry
        #Severity
        severity_options = ["low","meduim","high"]
        severity_var = StringVar(edit_bug_wf)
        severity_var.set(bugsdict[place][bug]["severity"])
        severity_label = Label(edit_bug_wf,text="Severity")
        severity_label.grid(row=7,column=0)
        severity_entry = OptionMenu(edit_bug_wf,severity_var,*severity_options)
        severity_entry.grid(row=7,column=1)
        #Submit button for all the information
        submit_button = Button(edit_bug_wf,text="Submit",
                        command=edit_json)
        submit_button.grid(row=8, column=0, columnspan=2)
    row = 0
    #Window to show bug information
    bug_info_w = Toplevel(root)
    #Frame for window
    bug_info_wf = Frame(bug_info_w)
    bug_info_wf.pack()
    #Go through all the information, adding it to the screen
    for info in bugsdict[place][bug]:
        l_1 = Label(bug_info_wf,text=info.title())
        l_1.grid(row=row,column=0,padx=5,pady=5)
        l_2 = Label(bug_info_wf,text=bugsdict[place][bug][info])
        l_2.grid(row=row,column=1,padx=5,pady=5)
        row+=1
    move_button = Button(bug_info_wf,text="Move to Next Stage",command=move_bug)
    move_button.grid(row=row,column=0)
    edit_button = Button(bug_info_wf,text="Edit Bug Info",command=edit_bug)
    edit_button.grid(row=row,column=1)

def create_window():
    '''Create the window of bug buttons'''
    #Variables to keep track of where buttons are being placed
    row = 2
    col = 0
    colspan = 1
    #Clear the screen
    for widget in root_frame.winfo_children():
        widget.destroy()
    #Button to add a new bug
    add_bug_button = tk.Button(root_frame,text="Add Bug",command=add_bug)
    add_bug_button.grid(row=0,column=0,columnspan = 4)
    #Go through each of the labels in the dictionary
    for place in bugsdict:
        colspan = 1
        row = 2
        for bug in range(len(bugsdict[place])):
            #Create the button to show bug information
            b_1 = Button(root_frame,text=bugsdict[place][bug]["Bug ID"],
                         width=8,height=2,
                         command=lambda place=place,bug=bug:show_info(place,bug))
            #Color the button based of severity
            if bugsdict[place][bug]["severity"] == "low":
                b_1.config(bg="darkgreen")
            elif bugsdict[place][bug]["severity"] == "high":
                b_1.config(bg="red")
            else:
                b_1.config(bg="yellow")
            #Place on screen
            b_1.grid(row=row,column=col,padx=5,pady=5)
            #Increment the row
            row+=1
            #Make only 4 buttons per column
            if row > 5:
                row = 2
                colspan+=1
                col+=1
        label = Label(root_frame,text=place.title())
        label.grid(row=1,column=col-colspan+1,columnspan=colspan)
        col+=1

create_window()
root.mainloop()
